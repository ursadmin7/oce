# Online Code Editor (Playground)

Simple browser-based code playground with HTML/CSS/JS editors, live preview, localStorage, theme toggle, and console output.

How to use
- Open `index.html` in your browser.
- Type code into HTML / CSS / JS panels — preview updates automatically.
- Buttons: `Run`, `Clear`, `Copy` (combined HTML), `Download` (single HTML file), Theme toggle.
 - Shortcuts: `Ctrl+S` saves to localStorage, `Ctrl+Enter` runs preview.

Advanced features
- Project save/load: save named projects to Local Storage and load them from the header dropdown.
- Export ZIP: download the current project as a ZIP (HTML/CSS/JS) using JSZip.
- Per-editor copy buttons to copy HTML/CSS/JS individually.
- Auto-run toggle to update preview as you type (debounced).
- Clear console button and improved console output styling.
- Resizable panels: drag splitters between editors and preview, and between stacked editors.

Files
- index.html — main UI
- css/styles.css — styles
- js/app.js — main behavior (uses CodeMirror via CDN)

Notes
- For syntax highlighting this project uses CodeMirror 5 from CDN.
- The preview is rendered via `iframe.srcdoc` and a small console bridge posts messages to the parent window.
