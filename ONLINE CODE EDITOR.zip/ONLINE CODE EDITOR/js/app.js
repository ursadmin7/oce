// Playground app.js — final corrected implementation
document.addEventListener('DOMContentLoaded', () => {
  const LS_HTML = 'playground.html';
  const LS_CSS = 'playground.css';
  const LS_JS = 'playground.js';
  const debounce = (fn, wait = 300) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), wait); }; };

  const htmlTA = document.getElementById('htmlEditor');
  const cssTA = document.getElementById('cssEditor');
  const jsTA = document.getElementById('jsEditor');
  const preview = document.getElementById('preview');
  const runBtn = document.getElementById('runBtn');
  const clearBtn = document.getElementById('clearBtn');
  const copyBtn = document.getElementById('copyBtn');
  const downloadBtn = document.getElementById('downloadBtn');
  const toggleThemeBtn = document.getElementById('toggleTheme');
  const consoleOutput = document.getElementById('consoleOutput');
  // advanced controls
  const projectNameInput = document.getElementById('projectName');
  const saveProjectBtn = document.getElementById('saveProject');
  const loadProjectSelect = document.getElementById('loadProject');
  const exportZipBtn = document.getElementById('exportZip');
  const autoRunCheckbox = document.getElementById('autoRun');
  const clearConsoleBtn = document.getElementById('clearConsole');
  const copyHtmlBtn = document.getElementById('copyHtml');
  const copyCssBtn = document.getElementById('copyCss');
  const copyJsBtn = document.getElementById('copyJs');

  if (typeof CodeMirror === 'undefined') { console.error('CodeMirror not loaded'); alert('CodeMirror failed to load.'); return; }

  const htmlEditor = CodeMirror.fromTextArea(htmlTA, { mode: 'htmlmixed', lineNumbers: true, theme: 'dracula' });
  const cssEditor = CodeMirror.fromTextArea(cssTA, { mode: 'css', lineNumbers: true, theme: 'dracula' });
  const jsEditor = CodeMirror.fromTextArea(jsTA, { mode: 'javascript', lineNumbers: true, theme: 'dracula' });

  function setTheme(isLight) {
    document.body.classList.toggle('light', isLight);
    const theme = isLight ? 'eclipse' : 'dracula';
    [htmlEditor, cssEditor, jsEditor].forEach(e => e.setOption('theme', theme));
    toggleThemeBtn.textContent = isLight ? 'Dark' : 'Light';
  }

  function restore() {
    const h = localStorage.getItem(LS_HTML) || '<h1>Hello World</h1>';
    const c = localStorage.getItem(LS_CSS) || 'body{font-family:Inter, sans-serif}';
    const j = localStorage.getItem(LS_JS) || 'console.log("Ready")';
    htmlEditor.setValue(h); cssEditor.setValue(c); jsEditor.setValue(j);
  }

  function safeInject(str, tag) {
    if (!str) return '';
    return str.replace(new RegExp('</\\s*' + tag + '>', 'gi'), m => m.replace('/', '\\/'));
  }

  function buildPreviewDoc() {
    const h = htmlEditor.getValue();
    const c = safeInject(cssEditor.getValue(), 'style');
    const j = safeInject(jsEditor.getValue(), 'script');
    return `<!doctype html><html><head><meta charset="utf-8"><style>${c}</style></head><body>${h}
    <script>
      (function(){
        function send(type,args){parent.postMessage({type:type,args:args}, '*');}
        const oldLog = console.log; console.log = function(){ send('log',Array.from(arguments)); oldLog.apply(console,arguments); };
        const oldErr = console.error; console.error = function(){ send('error',Array.from(arguments)); oldErr.apply(console,arguments); };
        window.addEventListener('error', function(e){ send('error',[e.message+' at '+(e.filename||'')+':'+(e.lineno||'')]); });
      })();
    </script>
    <script>${j}\n</script></body></html>`;
  }

  function updatePreview() { preview.srcdoc = buildPreviewDoc(); }

  let autoRunEnabled = autoRunCheckbox && autoRunCheckbox.checked;
  if (autoRunCheckbox) autoRunCheckbox.addEventListener('change', () => { autoRunEnabled = autoRunCheckbox.checked; });
  const saveAndPreview = debounce(() => { localStorage.setItem(LS_HTML, htmlEditor.getValue()); localStorage.setItem(LS_CSS, cssEditor.getValue()); localStorage.setItem(LS_JS, jsEditor.getValue()); if (autoRunEnabled) updatePreview(); }, 250);

  htmlEditor.on('change', saveAndPreview); cssEditor.on('change', saveAndPreview); jsEditor.on('change', saveAndPreview);

  runBtn.addEventListener('click', updatePreview);
  clearBtn.addEventListener('click', () => { if (!confirm('Clear all editors?')) return; htmlEditor.setValue(''); cssEditor.setValue(''); jsEditor.setValue(''); localStorage.removeItem(LS_HTML); localStorage.removeItem(LS_CSS); localStorage.removeItem(LS_JS); updatePreview(); consoleOutput.innerHTML = ''; });

  copyBtn.addEventListener('click', async () => { const text = buildPreviewDoc(); try { if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(text); else { const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); } alert('Combined HTML copied to clipboard'); } catch (e) { alert('Copy failed: ' + e.message); } });

  // per-editor copy
  if (copyHtmlBtn) copyHtmlBtn.addEventListener('click', async () => { const t = htmlEditor.getValue(); try { await navigator.clipboard.writeText(t); alert('HTML copied'); } catch (e) { alert('Copy failed'); } });
  if (copyCssBtn) copyCssBtn.addEventListener('click', async () => { const t = cssEditor.getValue(); try { await navigator.clipboard.writeText(t); alert('CSS copied'); } catch (e) { alert('Copy failed'); } });
  if (copyJsBtn) copyJsBtn.addEventListener('click', async () => { const t = jsEditor.getValue(); try { await navigator.clipboard.writeText(t); alert('JS copied'); } catch (e) { alert('Copy failed'); } });

  // clear console
  if (clearConsoleBtn) clearConsoleBtn.addEventListener('click', () => { consoleOutput.innerHTML = ''; });

  downloadBtn.addEventListener('click', () => { const blob = new Blob([buildPreviewDoc()], { type: 'text/html' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'playground.html'; a.click(); URL.revokeObjectURL(url); });

  window.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); localStorage.setItem(LS_HTML, htmlEditor.getValue()); localStorage.setItem(LS_CSS, cssEditor.getValue()); localStorage.setItem(LS_JS, jsEditor.getValue()); alert('Saved'); } if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); updatePreview(); } });

  window.addEventListener('message', (ev) => { try { const msg = ev.data; if (!msg || !msg.type) return; const el = document.createElement('div'); el.className = 'console-line ' + msg.type; el.textContent = msg.args.map(a => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' '); consoleOutput.appendChild(el); consoleOutput.scrollTop = consoleOutput.scrollHeight; } catch (e) { console.error(e); } });

  toggleThemeBtn.addEventListener('click', () => { const isLight = document.body.classList.toggle('light'); setTheme(isLight); });

  (function () { const splitter = document.getElementById('editPreviewSplitter'); const left = document.querySelector('.editors > .editor-column:first-child'); const right = document.querySelector('.editors > .editor-column:last-child'); if (!splitter || !left || !right) return; let dragging = false, startX = 0, leftWidth = 0; splitter.addEventListener('mousedown', (e) => { dragging = true; startX = e.clientX; leftWidth = left.getBoundingClientRect().width; document.body.style.cursor = 'col-resize'; }); window.addEventListener('mousemove', (e) => { if (!dragging) return; const dx = e.clientX - startX; const newLeft = leftWidth + dx; const total = left.parentElement.getBoundingClientRect().width; const px = Math.max(200, Math.min(total - 200, newLeft)); left.style.flex = '0 0 ' + px + 'px'; right.style.flex = '1'; }); window.addEventListener('mouseup', () => { if (dragging) { dragging = false; document.body.style.cursor = ''; } }); })();

  // horizontal splitter between HTML and CSS
  (function(){
    const hSplitter = document.querySelector('.splitter[data-split="vertical"]');
    if(!hSplitter) return;
    const topCard = document.querySelector('.editor-column .editor-card:first-child');
    const bottomCard = topCard ? topCard.nextElementSibling.nextElementSibling : null; // account for splitter element
    if(!topCard || !bottomCard) return;
    let draggingH=false, startY=0, topHeight=0;
    hSplitter.addEventListener('mousedown', (e)=>{ draggingH=true; startY=e.clientY; topHeight = topCard.getBoundingClientRect().height; document.body.style.cursor='row-resize'; e.preventDefault(); });
    window.addEventListener('mousemove', (e)=>{ if(!draggingH) return; const dy = e.clientY - startY; const newH = Math.max(100, topHeight + dy); topCard.style.flex = '0 0 '+newH+'px'; bottomCard.style.flex = '1'; htmlEditor.refresh(); cssEditor.refresh(); jsEditor.refresh(); });
    window.addEventListener('mouseup', ()=>{ if(draggingH){ draggingH=false; document.body.style.cursor=''; } });
  })();

  // project save/load
  function loadProjectList(){
    const raw = localStorage.getItem('playground.projects');
    const map = raw? JSON.parse(raw) : {};
    // clear select
    if(loadProjectSelect){ loadProjectSelect.innerHTML = '<option value="">Load project...</option>'; Object.keys(map).forEach(name=>{ const opt=document.createElement('option'); opt.value=name; opt.textContent=name; loadProjectSelect.appendChild(opt); }); }
  }
  function saveProject(){
    let name = projectNameInput && projectNameInput.value.trim(); if(!name) name = prompt('Project name:'); if(!name) return;
    const raw = localStorage.getItem('playground.projects'); const map = raw? JSON.parse(raw):{};
    map[name] = { html: htmlEditor.getValue(), css: cssEditor.getValue(), js: jsEditor.getValue(), saved: Date.now() };
    localStorage.setItem('playground.projects', JSON.stringify(map)); loadProjectList(); alert('Saved project '+name);
  }
  if(saveProjectBtn) saveProjectBtn.addEventListener('click', saveProject);
  if(loadProjectSelect) loadProjectSelect.addEventListener('change',(e)=>{ const name=e.target.value; if(!name) return; const raw=localStorage.getItem('playground.projects'); const map = raw? JSON.parse(raw):{}; if(map[name]){ htmlEditor.setValue(map[name].html); cssEditor.setValue(map[name].css); jsEditor.setValue(map[name].js); updatePreview(); } });

  if(exportZipBtn) exportZipBtn.addEventListener('click', async ()=>{
    if(typeof JSZip === 'undefined'){ alert('JSZip not loaded'); return; }
    const zip = new JSZip(); zip.file('index.html', buildPreviewDoc()); zip.file('styles.css', cssEditor.getValue()); zip.file('script.js', jsEditor.getValue()); const blob = await zip.generateAsync({type:'blob'}); const url = URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='project.zip'; a.click(); URL.revokeObjectURL(url);
  });

  loadProjectList();

  restore(); updatePreview(); setTheme(false);
});
